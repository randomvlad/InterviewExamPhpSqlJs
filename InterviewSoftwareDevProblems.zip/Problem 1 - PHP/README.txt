Problem 1 - PHP: User Campaign Report

Process data from two different sources and generate a summary user campaign performance report.

Report requirements:
- report on every user provided
- sort the report by profit from highest to lowest
- profit is defined as: revenue - cost

Implement the generate function in UserCampaignReport.class.php. Use PHP version 5.4 or higher.

To run the report, execute: php run_user_report.php