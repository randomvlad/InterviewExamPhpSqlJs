<?php

class UserCampaignReport {

  /**
   * @return array of arrays with keys: user, numberCampaigns, numberAds, profit. Data is sorted by profit in descending order.
   */
  public function generate(array $users, array $campaignsData, array $adLaunchEvents) {

    // TODO: implement me

    return [];
  }
}