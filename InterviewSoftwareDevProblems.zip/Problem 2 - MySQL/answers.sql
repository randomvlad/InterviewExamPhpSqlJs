-- Answer queries for Problem 2

-- Question #1


-- Question #2


-- Question #3


-- Question #4


-- Question #5

